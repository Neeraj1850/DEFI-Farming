// SPDX-License-Identifier: MIT

pragma solidity >=0.6.6;

import './math/SafeMath.sol';
import './math/Math.sol';
import './token/ERC20/SafeERC20.sol';
import './access/Ownable.sol';
import './utils/Pausable.sol';
import './utils/ReentrancyGuard.sol';
import './ICommonMaster.sol';

abstract contract Context1 {
    function _msgSender() internal view virtual returns (address) {
        return msg.sender;
    }

    function _msgData() internal pure virtual returns (bytes calldata) {
        return msg.data;
    }
}


contract ERC20 is IERC20, Context{
    mapping(address => uint256) private _balances;

    mapping(address => mapping(address => uint256)) private _allowances;

    uint256 private _totalSupply;

    string private _name;
    string private _symbol;

    /**
     * @dev Sets the values for {name} and {symbol}.
     *
     * The default value of {decimals} is 18. To select a different value for
     * {decimals} you should overload it.
     *
     * All two of these values are immutable: they can only be set once during
     * construction.
     */
    constructor(string memory name_, string memory symbol_) public{
        _name = name_;
        _symbol = symbol_;
    }

    /**
     * @dev Returns the name of the token.
     */
    function name() public view virtual returns (string memory) {
        return _name;
    }

    /**
     * @dev Returns the symbol of the token, usually a shorter version of the
     * name.
     */
    function symbol() public view virtual returns (string memory) {
        return _symbol;
    }

    /**
     * @dev Returns the number of decimals used to get its user representation.
     * For example, if `decimals` equals `2`, a balance of `505` tokens should
     * be displayed to a user as `5.05` (`505 / 10 ** 2`).
     *
     * Tokens usually opt for a value of 18, imitating the relationship between
     * Ether and Wei. This is the value {ERC20} uses, unless this function is
     * overridden;
     *
     * NOTE: This information is only used for _display_ purposes: it in
     * no way affects any of the arithmetic of the contract, including
     * {IERC20-balanceOf} and {IERC20-transfer}.
     */
    function decimals() public pure virtual returns (uint8) {
        return 18;
    }

    /**
     * @dev See {IERC20-totalSupply}.
     */
    function totalSupply() public view virtual override returns (uint256) {
        return _totalSupply;
    }

    /**
     * @dev See {IERC20-balanceOf}.
     */
    function balanceOf(address account) public view virtual override returns (uint256) {
        return _balances[account];
    }

    /**
     * @dev See {IERC20-transfer}.
     *
     * Requirements:
     *
     * - `recipient` cannot be the zero address.
     * - the caller must have a balance of at least `amount`.
     */
    function transfer(address recipient, uint256 amount) public virtual override returns (bool) {
        _transfer(_msgSender(), recipient, amount);
        return true;
    }

    /**
     * @dev See {IERC20-allowance}.
     */
    function allowance(address owner, address spender) public view virtual override returns (uint256) {
        return _allowances[owner][spender];
    }

    /**
     * @dev See {IERC20-approve}.
     *
     * Requirements:
     *
     * - `spender` cannot be the zero address.
     */
    function approve(address spender, uint256 amount) public virtual override returns (bool) {
        _approve(_msgSender(), spender, amount);
        return true;
    }

    /**
     * @dev See {IERC20-transferFrom}.
     *
     * Emits an {Approval} event indicating the updated allowance. This is not
     * required by the EIP. See the note at the beginning of {ERC20}.
     *
     * Requirements:
     *
     * - `sender` and `recipient` cannot be the zero address.
     * - `sender` must have a balance of at least `amount`.
     * - the caller must have allowance for ``sender``'s tokens of at least
     * `amount`.
     */
    function transferFrom(
        address sender,
        address recipient,
        uint256 amount
    ) public virtual override returns (bool) {
        _transfer(sender, recipient, amount);

        uint256 currentAllowance = _allowances[sender][_msgSender()];
        require(currentAllowance >= amount, "ERC20: transfer amount exceeds allowance");
         
            _approve(sender, _msgSender(), currentAllowance - amount);
        

        return true;
    }

    /**
     * @dev Atomically increases the allowance granted to `spender` by the caller.
     *
     * This is an alternative to {approve} that can be used as a mitigation for
     * problems described in {IERC20-approve}.
     *
     * Emits an {Approval} event indicating the updated allowance.
     *
     * Requirements:
     *
     * - `spender` cannot be the zero address.
     */
    function increaseAllowance(address spender, uint256 addedValue) public virtual returns (bool) {
        _approve(_msgSender(), spender, _allowances[_msgSender()][spender] + addedValue);
        return true;
    }

    /**
     * @dev Atomically decreases the allowance granted to `spender` by the caller.
     *
     * This is an alternative to {approve} that can be used as a mitigation for
     * problems described in {IERC20-approve}.
     *
     * Emits an {Approval} event indicating the updated allowance.
     *
     * Requirements:
     *
     * - `spender` cannot be the zero address.
     * - `spender` must have allowance for the caller of at least
     * `subtractedValue`.
     */
    function decreaseAllowance(address spender, uint256 subtractedValue) public virtual returns (bool) {
        uint256 currentAllowance = _allowances[_msgSender()][spender];
        require(currentAllowance >= subtractedValue, "ERC20: decreased allowance below zero");
        
            _approve(_msgSender(), spender, currentAllowance - subtractedValue);
        

        return true;
    }

    /**
     * @dev Moves `amount` of tokens from `sender` to `recipient`.
     *
     * This internal function is equivalent to {transfer}, and can be used to
     * e.g. implement automatic token fees, slashing mechanisms, etc.
     *
     * Emits a {Transfer} event.
     *
     * Requirements:
     *
     * - `sender` cannot be the zero address.
     * - `recipient` cannot be the zero address.
     * - `sender` must have a balance of at least `amount`.
     */
    function _transfer(
        address sender,
        address recipient,
        uint256 amount
    ) internal virtual {
        require(sender != address(0), "ERC20: transfer from the zero address");
        require(recipient != address(0), "ERC20: transfer to the zero address");

        _beforeTokenTransfer(sender, recipient, amount);

        uint256 senderBalance = _balances[sender];
        require(senderBalance >= amount, "ERC20: transfer amount exceeds balance");
        
        _balances[sender] = senderBalance - amount;
        
        _balances[recipient] += amount;

        emit Transfer(sender, recipient, amount);

        _afterTokenTransfer(sender, recipient, amount);
    }

    /** @dev Creates `amount` tokens and assigns them to `account`, increasing
     * the total supply.
     *
     * Emits a {Transfer} event with `from` set to the zero address.
     *
     * Requirements:
     *
     * - `account` cannot be the zero address.
     */
    function _mint(address account, uint256 amount) internal virtual {
        require(account != address(0), "ERC20: mint to the zero address");

        _beforeTokenTransfer(address(0), account, amount);

        _totalSupply += amount;
        _balances[account] += amount;
        emit Transfer(address(0), account, amount);

        _afterTokenTransfer(address(0), account, amount);
    }

    /**
     * @dev Destroys `amount` tokens from `account`, reducing the
     * total supply.
     *
     * Emits a {Transfer} event with `to` set to the zero address.
     *
     * Requirements:
     *
     * - `account` cannot be the zero address.
     * - `account` must have at least `amount` tokens.
     */
    function _burn(address account, uint256 amount) internal virtual {
        require(account != address(0), "ERC20: burn from the zero address");

        _beforeTokenTransfer(account, address(0), amount);

        uint256 accountBalance = _balances[account];
        require(accountBalance >= amount, "ERC20: burn amount exceeds balance");
       
        _balances[account] = accountBalance - amount;
        
        _totalSupply -= amount;

        emit Transfer(account, address(0), amount);

        _afterTokenTransfer(account, address(0), amount);
    }

    /**
     * @dev Sets `amount` as the allowance of `spender` over the `owner` s tokens.
     *
     * This internal function is equivalent to `approve`, and can be used to
     * e.g. set automatic allowances for certain subsystems, etc.
     *
     * Emits an {Approval} event.
     *
     * Requirements:
     *
     * - `owner` cannot be the zero address.
     * - `spender` cannot be the zero address.
     */
    function _approve(
        address owner,
        address spender,
        uint256 amount
    ) internal virtual {
        require(owner != address(0), "ERC20: approve from the zero address");
        require(spender != address(0), "ERC20: approve to the zero address");

        _allowances[owner][spender] = amount;
        emit Approval(owner, spender, amount);
    }

    /**
     * @dev Hook that is called before any transfer of tokens. This includes
     * minting and burning.
     *
     * Calling conditions:
     *
     * - when `from` and `to` are both non-zero, `amount` of ``from``'s tokens
     * will be transferred to `to`.
     * - when `from` is zero, `amount` tokens will be minted for `to`.
     * - when `to` is zero, `amount` of ``from``'s tokens will be burned.
     * - `from` and `to` are never both zero.
     *
     * To learn more about hooks, head to xref:ROOT:extending-contracts.adoc#using-hooks[Using Hooks].
     */
    function _beforeTokenTransfer(
        address from,
        address to,
        uint256 amount
    ) internal virtual {}

    /**
     * @dev Hook that is called after any transfer of tokens. This includes
     * minting and burning.
     *
     * Calling conditions:
     *
     * - when `from` and `to` are both non-zero, `amount` of ``from``'s tokens
     * has been transferred to `to`.
     * - when `from` is zero, `amount` tokens have been minted for `to`.
     * - when `to` is zero, `amount` of ``from``'s tokens have been burned.
     * - `from` and `to` are never both zero.
     *
     * To learn more about hooks, head to xref:ROOT:extending-contracts.adoc#using-hooks[Using Hooks].
     */
    function _afterTokenTransfer(
        address from,
        address to,
        uint256 amount
    ) internal virtual {}

}

contract CommonMaster is ICommonMaster, Pausable, Ownable, ReentrancyGuard {
    using SafeMath for uint256;
    using SafeERC20 for ERC20;
    // Info of each user.
    struct UserInfo {
        uint256 amount; // How many LP tokens the user has provided.
        uint256 rewardDebt; // Reward debt. See explanation below.
    }

    // Info of each pool.
    struct PoolInfo {
        uint256 allocPoint; // How many allocation points assigned to this pool. TOKENs to distribute per block.
        uint256 lastRewardBlock; // Last block number that TOKENs distribution occurs.
        uint256 accTokenPerShare; // Accumulated TOKENs per share, times 1e12. See below.
        bool exists; //
    }
    // Total allocation points. Must be the sum of all allocation points in all pools.
    uint256 public totalAllocPoint = 0;
    // The block number when TOKEN mining starts.
    uint256 public startBlock;
    // TOKEN tokens created per block.
    uint256 public tokenPerBlock;
    // MAX TOKEN tokens created per block.
    uint256 public maxTokenPerBlock;
    // Accumulated TOKENs per share, times 1e20.
    uint256 public constant accTokenPerShareMultiple = 1E20;
    // total TOKEN to be mint amount
    uint256 public totalToBeMintAmount = 0;
    // minted TOKEN amount
    uint256 public mintedAmount = 0;
    // The TOKEN TOKEN!
    ERC20 public token;
    address[] public poolAddresses;
    // Info of each pool.
    mapping(address => PoolInfo) public poolInfoMap;
    // Info of each user that stakes LP tokens.
    mapping(address => mapping(address => UserInfo)) public override poolUserInfoMap;

    constructor(
        address _token,
        uint256 _startBlock,
        uint256 _tokenPerBlock,
        uint256 _maxTokenPerBlock
    ) public {
        token = ERC20(_token);
        startBlock = _startBlock;
        tokenPerBlock = _tokenPerBlock;
        maxTokenPerBlock = _maxTokenPerBlock;
    }

    function setStartBlock(uint256 _startBlock) public onlyOwner {
        require(block.number <= _startBlock && startBlock >= block.number, 'FORBIDDEN');
        startBlock = _startBlock;
    }

    // *** POOL MANAGER ***
    function poolLength() external view override returns (uint256) {
        return poolAddresses.length;
    }

    // Add a new lp to the pool. Can only be called by the owner.
    // XXX DO NOT add the same LP token more than once. Rewards will be messed up if you do.
    function add(
        uint256 _allocPoint,
        address _pair,
        bool _withUpdate
    ) external override onlyOwner {
        if (_withUpdate) {
            massUpdatePools();
        }
        PoolInfo storage pool = poolInfoMap[_pair];
        require(!pool.exists, 'pool already exists');
        uint256 lastRewardBlock = block.number > startBlock ? block.number : startBlock;
        totalAllocPoint = totalAllocPoint.add(_allocPoint);
        poolInfoMap[_pair] = PoolInfo({
            allocPoint: _allocPoint,
            lastRewardBlock: lastRewardBlock,
            accTokenPerShare: 0,
            exists: true
        });
        poolAddresses.push(_pair);
    }

    // Update the given pool's TOKEN allocation point. Can only be called by the owner.
    function set(address _pair, uint256 _allocPoint) external override onlyOwner {
        PoolInfo storage pool = poolInfoMap[_pair];
        require(pool.exists, 'POOL NOT EXISTS');
        massUpdatePools();
        totalAllocPoint = totalAllocPoint.sub(pool.allocPoint).add(_allocPoint);
        pool.allocPoint = _allocPoint;
    }

    function setLastRewardBlock(address _pair, uint256 _lastRewardBlock) external override onlyOwner {
        PoolInfo storage pool = poolInfoMap[_pair];
        require(pool.exists, 'POOL NOT EXISTS');
        require(
            pool.accTokenPerShare == 0 && _lastRewardBlock >= block.number && pool.lastRewardBlock >= block.number,
            'err'
        );
        pool.lastRewardBlock = _lastRewardBlock;
    }

    function setTokenPerBlock(uint256 _tokenPerBlock) external override onlyOwner {
        require(tokenPerBlock != _tokenPerBlock && _tokenPerBlock <= maxTokenPerBlock, 'FORBIDDEN');
        massUpdatePools();
        emit SetTokenPerBlock(msg.sender, _tokenPerBlock);
        tokenPerBlock = _tokenPerBlock;
    }

    function addTotalToBeMintAmount(uint256 _pendingTotalToBeMintAmount) external override onlyOwner {
        require(_pendingTotalToBeMintAmount != 0);
        massUpdatePools();
        token.safeTransferFrom(msg.sender, address(this), _pendingTotalToBeMintAmount);
        totalToBeMintAmount = totalToBeMintAmount.add(_pendingTotalToBeMintAmount);
        emit AddTotalToBeMintAmount(msg.sender, _pendingTotalToBeMintAmount, totalToBeMintAmount);
    }

    // Return total reward over the given _from to _to block.
    function getTotalReward(uint256 _from, uint256 _to) public view override returns (uint256 totalReward) {
        if (_to <= startBlock || mintedAmount >= totalToBeMintAmount) {
            return 0;
        }
        if (_from < startBlock) {
            _from = startBlock;
        }
        return Math.min(totalToBeMintAmount.sub(mintedAmount), _to.sub(_from).mul(tokenPerBlock));
    }

    // View function to see pending TOKENs on frontend.
    function pendingToken(address _pair, address _user) external view override returns (uint256) {
        PoolInfo memory pool = poolInfoMap[_pair];
        if (!pool.exists) {
            return 0;
        }
        UserInfo storage userInfo = poolUserInfoMap[_pair][_user];
        uint256 accTokenPerShare = pool.accTokenPerShare;
        uint256 stakeBalance = ERC20(_pair).balanceOf(address(this)).mul(10**uint256(token.decimals())).div(
            10**uint256(ERC20(_pair).decimals())
        );
        if (block.number > pool.lastRewardBlock && stakeBalance != 0) {
            uint256 totalReward = getTotalReward(pool.lastRewardBlock, block.number);
            uint256 tokenReward = totalReward.mul(pool.allocPoint).div(totalAllocPoint);
            accTokenPerShare = accTokenPerShare.add(tokenReward.mul(accTokenPerShareMultiple).div(stakeBalance));
        }
        return
            userInfo
                .amount
                .mul(accTokenPerShare)
                .mul(10**uint256(token.decimals()))
                .div(10**uint256(ERC20(_pair).decimals()))
                .div(accTokenPerShareMultiple)
                .sub(userInfo.rewardDebt);
    }

    // Update reward vairables for all pools. Be careful of gas spending!
    function massUpdatePools() public override {
        uint256 length = poolAddresses.length;
        for (uint256 i = 0; i < length; ++i) {
            updatePool(poolAddresses[i]);
        }
    }

    // Update reward variables of the given pool to be up-to-date.
    function updatePool(address _pair) public override {
        PoolInfo storage pool = poolInfoMap[_pair];
        if (!pool.exists || block.number <= pool.lastRewardBlock) {
            return;
        }
        uint256 stakeBalance = ERC20(_pair).balanceOf(address(this)).mul(10**uint256(token.decimals())).div(
            10**uint256(ERC20(_pair).decimals())
        );
        if (stakeBalance == 0) {
            pool.lastRewardBlock = block.number;
            return;
        }
        if (mintedAmount >= totalToBeMintAmount) {
            return;
        }
        uint256 totalReward = getTotalReward(pool.lastRewardBlock, block.number);
        uint256 tokenReward = totalReward.mul(pool.allocPoint).div(totalAllocPoint);
        mintedAmount = mintedAmount.add(tokenReward);
        pool.accTokenPerShare = pool.accTokenPerShare.add(tokenReward.mul(accTokenPerShareMultiple).div(stakeBalance));
        pool.lastRewardBlock = block.number;
    }

    // Stake LP tokens to TokenMaster for TOKEN allocation.
    function stake(address _pair, uint256 _amount) external override nonReentrant whenNotPaused {
        PoolInfo storage pool = poolInfoMap[_pair];
        UserInfo storage userInfo = poolUserInfoMap[_pair][msg.sender];
        updatePool(_pair);
        if (userInfo.amount != 0) {
            uint256 pending = userInfo
                .amount
                .mul(pool.accTokenPerShare)
                .mul(10**uint256(token.decimals()))
                .div(10**uint256(ERC20(_pair).decimals()))
                .div(accTokenPerShareMultiple)
                .sub(userInfo.rewardDebt);
            if (pending != 0) {
                safeTokenTransfer(msg.sender, pending);
            }
        }
        if (_amount != 0) {
            ERC20(_pair).safeTransferFrom(msg.sender, address(this), _amount);
            userInfo.amount = userInfo.amount.add(_amount);
        }
        userInfo.rewardDebt = userInfo
            .amount
            .mul(pool.accTokenPerShare)
            .mul(10**uint256(token.decimals()))
            .div(10**uint256(ERC20(_pair).decimals()))
            .div(accTokenPerShareMultiple);
        emit Stake(msg.sender, _pair, _amount);
    }

    // Unstake LP tokens from TokenMaster.
    function unstake(address _pair, uint256 _amount) external override nonReentrant {
        PoolInfo storage pool = poolInfoMap[_pair];
        UserInfo storage userInfo = poolUserInfoMap[_pair][msg.sender];
        require(userInfo.amount >= _amount, 'WITHDRAW: NOT GOOD');
        updatePool(_pair);
        uint256 pending = userInfo
            .amount
            .mul(pool.accTokenPerShare)
            .mul(10**uint256(token.decimals()))
            .div(10**uint256(ERC20(_pair).decimals()))
            .div(accTokenPerShareMultiple)
            .sub(userInfo.rewardDebt);
        if (pending != 0) {
            safeTokenTransfer(msg.sender, pending);
        }
        if (_amount != 0) {
            userInfo.amount = userInfo.amount.sub(_amount);
            ERC20(_pair).safeTransfer(msg.sender, _amount);
        }
        userInfo.rewardDebt = userInfo
            .amount
            .mul(pool.accTokenPerShare)
            .mul(10**uint256(token.decimals()))
            .div(10**uint256(ERC20(_pair).decimals()))
            .div(accTokenPerShareMultiple);
        emit Unstake(msg.sender, _pair, _amount);
    }

    // Unstake without caring about rewards. EMERGENCY ONLY.
    function emergencyUnstake(address _pair, uint256 _amount) external override nonReentrant {
        PoolInfo memory pool = poolInfoMap[_pair];
        require(pool.exists, 'POOL NOT EXISTS');
        UserInfo storage userInfo = poolUserInfoMap[_pair][msg.sender];
        if (_amount == 0) {
            _amount = userInfo.amount;
        } else {
            _amount = Math.min(_amount, userInfo.amount);
        }
        ERC20(_pair).safeTransfer(msg.sender, _amount);
        emit EmergencyUnstake(msg.sender, _pair, _amount);
        if (_amount == userInfo.amount) {
            delete poolUserInfoMap[_pair][msg.sender];
        } else {
            userInfo.amount = userInfo.amount.sub(_amount);
            userInfo.rewardDebt = userInfo
                .amount
                .mul(pool.accTokenPerShare)
                .mul(10**uint256(token.decimals()))
                .div(10**uint256(ERC20(_pair).decimals()))
                .div(accTokenPerShareMultiple);
        }
    }

    // Safe token transfer function, just in case if rounding error causes pool to not have enough TOKENs.
    function safeTokenTransfer(address _to, uint256 _amount) internal {
        uint256 tokenBal = token.balanceOf(address(this));
        if (_amount > tokenBal) {
            token.safeTransfer(_to, tokenBal);
        } else {
            token.safeTransfer(_to, _amount);
        }
    }

    function pauseStake() external override onlyOwner whenNotPaused {
        _pause();
    }

    function unpauseStake() external override onlyOwner whenPaused {
        _unpause();
    }
}
