// SPDX-License-Identifier: MIT

pragma solidity >=0.8.6;

import './access/Ownable.sol';
import './CommonMaster.sol';


contract CommonMasterFactory is Ownable {
    event CommonMasterCreated(address indexed commonMaster);

    constructor() {}

    function createCommonMaster(
        address _token,
        uint256 _startBlock,
        uint256 _tokenPerBlock,
        uint256 _maxTokenPerBlock
    ) external onlyOwner returns (address) {
        CommonMaster commonMaster = new CommonMaster(_token, _startBlock, _tokenPerBlock, _maxTokenPerBlock);
        Ownable(address(commonMaster)).transferOwnership(_msgSender());
        emit CommonMasterCreated(address(commonMaster));
        return address(commonMaster);
    }
}
